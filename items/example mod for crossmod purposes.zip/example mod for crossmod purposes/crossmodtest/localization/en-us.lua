return {
    descriptions = {
        Joker = {
            j_test_chips = {
                name = "Chip Collector",
                text = { "Gain +1 Chip" },
            },
            j_test_mult = {
                name = "not Chip Collector",
                text = { "Gain +1 Chip#2#" },
            },
            j_test_mult_alt = {
                name = "def not Chip Collector",
                text = { "Gain +1 Chip#2#" },
            },
            j_test_h = {
                name = "Hyper Chip Collector",
                text = { "Gain +5 Chips" },
            },
        },
    },
}
