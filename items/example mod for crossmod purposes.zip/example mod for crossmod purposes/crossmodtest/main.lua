G.C.hpfx_IjiGray = HEX('BFD7D5')
Testmod = SMODS.current_mod

SMODS.Atlas {
    key = 'good',
    path = "good.png",
    px = 71,
    py = 95
}
SMODS.Atlas {
    key = 'bad',
    path = "bad.png",
    px = 71,
    py = 95
}

SMODS.Joker { --chips
    key = 'chips',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    atlas = 'good',
    rarity = 1,
    cost = 1,
    config = {
        extra = {
            chips = 1,
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                chips = card.ability.extra.chips
            }
        end
    end,
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.chips
            }
        }
    end,
}
SMODS.Joker { --mult
    key = 'mult',
    pos = { x = 0, y = 0 },
    no_mod_badges = true,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    atlas = 'bad',
    rarity = 1,
    cost = 1,
    config = {
        extra = {
            mult = 1,
        }
    },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.mult,
                card.area and card.area == G.jokers and "...?" or ""
            }
        }
    end,
    generate_ui = function(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        full_UI_table.name = localize {
            type = 'name',
            set = "Joker",
            key = card.ability and card.ability.extra.new_key or "j_test_mult",
            nodes = {}
        }
        SMODS.Center.generate_ui(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
    end,
    add_to_deck = function(self, card, from_debuff)
        card.ability.extra.new_key = "j_test_mult_alt"
        local sticker = SMODS.Stickers['hpfx_priceless']
        sticker.apply(sticker, card, true)
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                mult = card.ability.extra.mult
            }
        end
    end,
    calc_dollar_bonus = function(self, card)
        return 4
    end
}

SMODS.Joker { --hyper chips (For a joker without a custom evil effect)
    key = 'h',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    atlas = 'good',
    rarity = 2,
    cost = 5,
    config = {
        extra = {
            chips = 5,
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                chips = card.ability.extra.chips,
                func = function()
                    hpfx_Transform(card, context)
                end
            }
        end
    end,
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.chips
            }
        }
    end,
    ijiraq_atlas = {
        atlas = 'bad',
        pos = { x = 0, y = 0 }
    }
}

if next(SMODS.find_mod('hyperfixation_mod')) then
    if Hyperglobal and Hyperglobal.hypercross then
        if type(Hyperglobal) == "table" and type(Hyperglobal.hypercross) == "function" then
            Hyperglobal.hypercross('crosstest', 'j_test_chips', 'j_test_mult', true)
        end
    end
end
