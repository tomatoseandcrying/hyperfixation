return {
    descriptions = {
        Joker = {
            j_test_broker = {
                name = 'Broker',
                text = {
                    'This is the first line of this description',
                    'This is the second line of this description',
                },
            },
            j_test_broken = {
                name = 'Broken',
                text = {
                    'This is the first line of this description',
                    'This is the second line of this description',
                },
            },
            j_test_broken_alt = {
                name = 'Broken Alt',
                text = {
                    'This is the first line of this description',
                    'This is the second line of this description',
                },
            },
        },
    },
}
